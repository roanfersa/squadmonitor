package br.com.globalsolutions.wellbeing.model;

public enum NivelAlerta {
    BAIXO,
    MEDIO,
    ALTO,
    CRITICO
}


